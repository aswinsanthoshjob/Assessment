import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;



public class FlightBooking3 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Aswin\\Selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
	try
	{
		//title and url validation
		driver.get("http://blazedemo.com/");
		String actualTitle1 = "BlazeDemo";
		String actualUrl1 = "https://blazedemo.com/";
		String title1 = driver.getTitle();
		String url1 = driver.getCurrentUrl();
		System.out.println("Title is " + title1 + " and URL is " + url1);
		Assert.assertEquals(title1, actualTitle1);
		Assert.assertEquals(url1, actualUrl1);
		System.out.println("Tile and URL validated successfully");
		
		//click on the link Destination of the Week.
		driver.findElement(By.partialLinkText("destination of the")).click();
		System.out.println("Navigated to previous page successfully");
		driver.findElement(By.cssSelector("img[class='img-rounded']")).isDisplayed();
		System.out.println("Image is displayed");
	}
	catch (Exception e)
	{
		System.out.println("Validation Failed");
	}
	finally
	{
		driver.quit();
	}
  }
}
