import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;



public class FlightBooking1 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Aswin\\Selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver,5);
	try
	{
		//title and url validation
		driver.get("http://blazedemo.com/");
		String actualTitle1 = "BlazeDemo";
		String actualUrl1 = "https://blazedemo.com/";
		String title1 = driver.getTitle();
		String url1 = driver.getCurrentUrl();
		System.out.println("Title is " + title1 + " and URL is " + url1);
		Assert.assertEquals(title1, actualTitle1);
		Assert.assertEquals(url1, actualUrl1);
		System.out.println("Tile and URL validated successfully");
		
		//selecting departure and destination city and find flights
		Select dep = new Select(driver.findElement(By.cssSelector("select[name='fromPort']")));
		dep.selectByValue("Mexico City");
		Select des = new Select(driver.findElement(By.cssSelector("select[name='toPort']")));
		des.selectByValue("Cairo");
		driver.findElement(By.cssSelector("input[value='Find Flights']")).click();
		System.out.println("Received the list of flights");
		String actualTitle2 = "BlazeDemo - reserve";
		String title2 = driver.getTitle();
		System.out.println("Title of page having list of flights is " + title2);
		Assert.assertEquals(title2, actualTitle2);
		
		//select the flight to be booked
		driver.findElement(By.xpath("//table[@class='table']/tbody/tr[1]/td[1]/input")).click();
		String actualTitle3 = "BlazeDemo Purchase";
		String title3 = driver.getTitle();
		System.out.println("Title of purchase page is " + title3);
		Assert.assertEquals(title3, actualTitle3);
		
		//wait for purchase page to load
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[name='inputName']")));
		
		//fill the details for purchase
		driver.findElement(By.cssSelector("input[name='inputName']")).sendKeys("JD");
		driver.findElement(By.cssSelector("input[name='address']")).sendKeys("7th Street, Indira Nagar");
		driver.findElement(By.cssSelector("input[name='city']")).sendKeys("Bangalore");
		driver.findElement(By.cssSelector("input[name='state']")).sendKeys("KA");
		driver.findElement(By.cssSelector("input[name='zipCode']")).sendKeys("560012");
		Select cardType = new Select(driver.findElement(By.cssSelector("select[name='cardType']")));
		cardType.selectByValue("amex");
		driver.findElement(By.cssSelector("input[name='creditCardNumber']")).sendKeys("0016523417824");
		driver.findElement(By.cssSelector("input[name='creditCardMonth']")).sendKeys("11");
		driver.findElement(By.cssSelector("input[name='creditCardYear']")).sendKeys("2025");
		driver.findElement(By.cssSelector("input[name='nameOnCard']")).sendKeys("JD");
		driver.findElement(By.cssSelector("input[type='submit']")).click();
		
		//wait for confirmation page to load
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(("/html/body/div[2]/div/h1"))));
		
		//validation of confirmation id
		String actualText = "Thank you for your purchase today!";
		String text = driver.findElement(By.xpath(("/html/body/div[2]/div/h1"))).getText();
		System.out.println(text);
		Assert.assertEquals(text, actualText);
		String confirmationId = driver.findElement(By.xpath("//table[@class='table']/tbody/tr[1]/td[2]")).getText();
		System.out.println(confirmationId);
		Assert.assertTrue(true, confirmationId);
		System.out.println("Validation of flight booking completed");
		
		//Navigating back to home page
		driver.findElement(By.linkText("Travel The World")).click();
		String title4 = driver.getTitle();
		System.out.println("Title is " + title4);
		Assert.assertEquals(title4, actualTitle1);
		System.out.println("Navigated back to the home page successfully");

		
	}
	catch (Exception e)
	{
		System.out.println("Validation Failed");
	}
	finally
	{
		driver.quit();
	}
  }
}
