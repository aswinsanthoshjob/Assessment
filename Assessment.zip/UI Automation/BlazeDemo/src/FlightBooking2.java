import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;



public class FlightBooking2 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Aswin\\Selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
	try
	{
		//title and url validation
		driver.get("http://blazedemo.com/");
		String actualTitle1 = "BlazeDemo";
		String actualUrl1 = "https://blazedemo.com/";
		String title1 = driver.getTitle();
		String url1 = driver.getCurrentUrl();
		System.out.println("Title is " + title1 + " and URL is " + url1);
		Assert.assertEquals(title1, actualTitle1);
		Assert.assertEquals(url1, actualUrl1);
		System.out.println("Tile and URL validated successfully");
		
		//selecting departure and destination city and find flights
		Select dep = new Select(driver.findElement(By.cssSelector("select[name='fromPort']")));
		dep.selectByValue("Mexico City");
		Select des = new Select(driver.findElement(By.cssSelector("select[name='toPort']")));
		des.selectByValue("Cairo");
		driver.findElement(By.cssSelector("input[value='Find Flights']")).click();
		System.out.println("Received the list of flights");
		String actualTitle2 = "BlazeDemo - reserve";
		String title2 = driver.getTitle();
		System.out.println("Title of page having list of flights is " + title2);
		Assert.assertEquals(title2, actualTitle2);
		
		//navigate to previous page by clicking back button
		driver.navigate().back();
		String title3 = driver.getTitle();
		System.out.println("Title is " + title3);
		Assert.assertEquals(title3, actualTitle1);
		System.out.println("Navigated to previous page successfully");
	}
	catch (Exception e)
	{
		System.out.println("Validation Failed");
	}
	finally
	{
		driver.quit();
	}
  }
}
